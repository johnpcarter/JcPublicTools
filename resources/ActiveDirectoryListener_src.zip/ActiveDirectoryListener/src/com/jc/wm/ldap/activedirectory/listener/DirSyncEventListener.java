package com.jc.wm.ldap.activedirectory.listener;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.ldap.Control;

import com.wm.app.b2b.server.InvokeState;
import com.wm.app.b2b.server.ServerAPI;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
import com.wm.app.b2b.server.Session;
import com.wm.app.b2b.server.User;
import com.wm.app.b2b.server.UserManager;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataFactory;
import com.wm.data.IDataUtil;

/**
 * Concrete implementation of {@link com.jc.ldap.activedirectory.listener.DirSyncEventListener} to integrate listener
 * in the webMethods integration server container i.e. leverage server and errors logs. Ensure that change events 
 * can be processed via a webMethods service rather than a java class.
 * 
 * @author John Carter
 *
 */
public class DirSyncEventListener extends com.jc.ldap.activedirectory.listener.DirSyncEventListener
{
	private static final String				SEARCH_FILTER = "(&(objectClass=person)(objectClass=user))";
	
	private static final String 			FIXED_RETURN_ATTRIBS[] = {"mail", "cn", "givenName", "whenCreated", "whenChanged"};
	
	private final static String				OBJECT_GUID = "objectGUID";
	private final static String				OBJECT_SID = "objectSid";
	private final static String 			USER_ID = "description";
	private final static String 			USER_NAME = "cn";
	private final static String 			USER_FNAME = "givenName";

	private final static String				USER_EMAIL = "mail";
	
	private final static String				NEW_DATE = "whenCreated";
	private final static String				CHG_DATE = "whenChanged";
	private final static String				IS_DELETED = "isDeleted";

	private String							_wmUserId;
	private String							_ifc;
	private String							_service;
	private File							_altLogFile;
	private URI								_altLogger;
	
	private String							_userIdAttribute;
	private Date							_dateAtMidnight;
	
	/**
	 * Establish a new DirSynControlEvent listener to listen for object changes in an Active Directory server
	 * Don't forget to call {@link #startup(long)} afterwards to start the background thread to monitor for events
	 * Used {@link #pleaseStop()} to gracefully stop it.
	 * 
	 * @param env 			Hashtable of ldap attributes to setup connection
	 * @param searchBase    directory root to scan, must a valid domain partition
	 * @param searchFilter	filter for active directory search (e.g. (&(objectClass=person)(objectClass=user))
	 * @param returnAttributes Optional list of attributes to check for updates, otherwise all attributes will be checked
	 * @param service		webMethods service to be invoked when processing change events
	 * @param userId		optional webMethods user id to be used when invoking service
	 * @param debugLevel	Either "Info", "Error", "Warn" or "Debug", specified whether to log or not to server log
	 * @throws NamingException
	 * @throws ServiceException
	 */
	public DirSyncEventListener(Hashtable<String, String> env, String searchBase, String searchFilter, String[] returnAttributes, String service, String userId, String debugLevel) throws NamingException, ServiceException
	{
		super(extendEnvToSupportBinaryIds(env), searchBase, searchFilter, configureSearchControls(returnAttributes), debugLevel);
	 
		setServiceToInvoke(service);
		
		_wmUserId = userId;
		_userIdAttribute = USER_ID;
		_dateAtMidnight = dateAtMidnight();
	}

	private static Hashtable<String, String> extendEnvToSupportBinaryIds(Hashtable<String, String> env)
	{
		 env.put("java.naming.ldap.attributes.binary", "objectSid objectGUID");	
		 
		 return env;
	}
	
	private static SearchControls configureSearchControls(String[] userReturnAttributes)
	{
		String[] returnedAtts = null;

		 if (userReturnAttributes != null)
			 returnedAtts = mergeFixedAndUserAttributes(userReturnAttributes, FIXED_RETURN_ATTRIBS);
		
		 SearchControls searchCtls = new SearchControls();
	      searchCtls.setReturningAttributes(returnedAtts);
	 
	      searchCtls.getReturningAttributes();
	      //Specify the search scope
	      searchCtls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	
	      //Specify the search time limit, in this case unlimited
	      searchCtls.setTimeLimit(0);
	 
	      return searchCtls;
	}

	/**
	 * active directory attribute to be used to identify users in business organisation
	 * 
	 * @return
	 */
	public String getUserIdAttributeName()
	{
		return _userIdAttribute;
	}
	
	/**
	 * Specify the active directory attribute to be used identify users in the business org
	 * 
	 * @param userIdType
	 * @throws ServiceException
	 */
	public void setUserIdAttributeName(String userIdType) throws ServiceException
	{
		String[] attributesToReturn = getSearchControls().getReturningAttributes();

		boolean found = false;
		
		if (attributesToReturn == null || attributesToReturn.length == 0)
		{
			found = true;
		}
		else
		{
			for (int i = 0; i < attributesToReturn.length; i++)
			{
				if (attributesToReturn[i].equals(userIdType))
				{
					found = true;
					break;
				}
			}
		}
		
		if (found)
			_userIdAttribute = userIdType;
		else
			throw new ServiceException("Add id type attributes to list of attributes to return");
	}
	
	/**
	 * Return a string identifying this listener, use to disntinguish between different listeners
	 * 
	 * @return
	 */
	public String getUniqueId()
	{
		return _service;
	}
	
	/**
	 * Return the full path of the webMethods service to be used for processing ldap change events
	 * 
	 * @return
	 */
	public String getServiceToInvoke()
	{
		return _ifc + ":" + _service;
	}
	
	/** set the webMethods service to be used for processing ldap change events
	 * 
	 * @param service
	 * @throws ServiceException
	 */
	public void setServiceToInvoke(String service) throws ServiceException
	{
		int indx = service.indexOf(":");
		
		if (indx != -1)
		{
			_ifc = service.substring(0, indx);
			_service = service.substring(indx+1);
		}
		else
		{
			throw new ServiceException("Invalid service name: " + service);
		}
	}
	
	/**
	 * Return the exception associated with connection thread
	 * 
	 */
	public Exception getConnectionError()
	{
		if (super.getConnectionError() instanceof ServiceException)
			return (ServiceException) super.getConnectionError();
		else
			return new ServiceException(super.getConnectionError());
	}
	
	public void setConnectionError(ServiceException e)
	{
		ServerAPI.logError(e);
		super.setConnectionError(e);
	}
	
	/**
	 * Attempts to interrogate the active directory for the user object with the given object GUI
	 * Returns a webMethods document containing all returned attributes
	 * 
	 * @param guid
	 * @return
	 * @throws NamingException
	 */
	public IData getUserInfoForGUIDString(String guid) throws NamingException
	{
		IData doc = IDataFactory.create();
		Attributes attributes = getAttributesForGUIDString(guid);
		
		if (attributes != null)
		{
			for (NamingEnumeration<? extends Attribute> ae = attributes.getAll(); ae.hasMore();)
			{
				Attribute attribute = (Attribute) ae.next();
				addAttributeToDocument(doc, attribute);
			}
		}
		
		return doc;
	}
	
	public void setAltLogger(String logName)
	{
		if (logName != null)
		{
			_altLogFile = new File(new File(ServerAPI.getServerConfigDir(), "../logs"), logName + ".log");
			_altLogger = _altLogFile.toURI();
		}
		else
		{
			_altLogFile = null;
			_altLogger = null;
		}
	}
	
	// abstract implementation
	
	@Override
	public void logError(Exception e, String message) 
	{
		ServerAPI.logError(e); 
		ServerAPI.logError(new ServiceException(message + ":" + e.getMessage()));
	}

	@Override
	public void logError(Exception e) 
	{
		ServerAPI.logError(e);
	}

	@Override
	public void logErrorMessage(String error) 
	{
		ServerAPI.logError(new ServiceException(error));		
	}
	
	/**
	 * Implementation to ensure that event changes can be delegated to a webMethods service
	 * Signature is defined by the webMethods specification ocp.tools.pub.ldap:ProcessingService
	 */
	@Override
	protected void processNotification(Attributes attrs)
	{		
		IData pipeline = null;
	
		try {
			pipeline = convertAttributesToDocument(attrs);
		} catch (NamingException e) 
		{
			logError(e, "Exception listing attributes: " + e);
		}
		
		try 
		{							
			if (pipeline != null)
			{
				setInvokeState(UserManager.getUser(_wmUserId));
			
				debugLog("Calling service:" + _service);
			
				Service.doThreadInvoke(_ifc, _service, pipeline);
			}
		}
		catch(Exception e)
		{
			logError(e, "Service '" + _ifc + ":" + _service + "' triggered exception:" + e);
		}
	}
	
	/**
	 * Persists the active directory cookie returned after each request to ensure change state 
	 * is maintained when stopping and starting the listener.
	 * 
	 */
	@Override
	protected void persistCookie(byte[] cookie)
	{
		 if (cookie != null)
		 {
			 try {
				 Files.write(Paths.get(ServerAPI.getPackageConfigDir("OcpPublicTools").getAbsolutePath(), "ad-dirsync-cookie_" + getUniqueId()), cookie);
			 } catch (IOException e) {
				logErrorMessage("Cannot persist ad ldap cookie: " + e);
			}
		 }
	 }
	                        
	@Override
	protected byte[] restoreCookie()
	{
		try {
			return Files.readAllBytes(Paths.get(ServerAPI.getPackageConfigDir("OcpPublicTools").getAbsolutePath(), "ad-dirsync-cookie_" + getUniqueId()));
		} catch (IOException e) {
			return null;
		}
	}
	 
	@Override
	protected boolean pleaseStart()
	{
		debugLog("starting ldap listener: " + _dateAtMidnight.toGMTString());

		return super.pleaseStart();
	}
	
	private IData convertAttributesToDocument(Attributes attrs) throws NamingException
	{
		Map<String, Object> attribs = new HashMap<String, Object>();
		String type = "CHG";
		String id = "";
		String firstName = "";
		String lastName = "";
		String email = "";
		String guid = "";
		byte[] guidbytes = null;
		String isDeleted = "false";
		
		Date newDate = null;
		Date changeDate = null;
		
		IData returnCodes = convertResponseCodeToDoc();
		
		IData attributesDoc = IDataFactory.create();
		
		for (NamingEnumeration<? extends Attribute> ae = attrs.getAll(); ae.hasMore();)
		{
			Attribute attribute = (Attribute) ae.next();
			
			if (attribute.getID().equals(OBJECT_GUID))
			{
				guidbytes = (byte[]) attribute.get();
				guid = convertByteGuidToString(guidbytes);
				
				attribs.put(attribute.getID(), guid);
			}
			else if (attribute.getID().equals(OBJECT_SID))
			{
				String sid = "";
				
				if (attribute.get() instanceof String)
				{
					sid = (String) attribute.get();
				}
				else
				{
					sid = convertByteGuidToString( (byte[]) attribute.get());
				}
				
				attribs.put(attribute.getID(), sid);
			}
			else if (attribute.getID().equals(IS_DELETED))
			{
				isDeleted = attribute.get().toString().toLowerCase();
				type = "DEL";
			}
			else if (attribute.getID().equals(_userIdAttribute))
			{
				//id = (String) attribute.get();
				id = (String) getAttributeValue(attribute);
			}
			else if (attribute.getID().equals(USER_EMAIL))
			{
				email = (String) getAttributeValue(attribute);
				
				attribs.put(attribute.getID(), email);
			}
			else if (attribute.getID().equals(USER_FNAME))
			{
				firstName = (String) getAttributeValue(attribute);
				
				attribs.put(attribute.getID(), firstName);
			}
			else if (attribute.getID().equals(USER_NAME))
			{
				String v = (String) getAttributeValue(attribute);
				attribs.put(attribute.getID(), v);
				
				if (v != null)
				{
					int index = -1;
				
					if ((index=v.indexOf(" ")) != -1)
						lastName = v.substring(0, index);
				}
			}
			else if ((type == null || !type.equals("DEL")) && attribute.getID().equals(NEW_DATE))
			{
				newDate = parseAdDate((String) getAttributeValue(attribute));
				
				if (newDate != null)
				{
					if (_dateAtMidnight.before(newDate))
						type = "NEW";
					else
						type = "CHG";
				
					attribs.put(attribute.getID(), newDate);
				}
			}
			else if (attribute.getID().equals(CHG_DATE))
			{
				changeDate = parseAdDate((String) getAttributeValue(attribute));
				
				if (changeDate != null)
					attribs.put(attribute.getID(), changeDate);
			}
			else
			{
				addAttributeToDocument(attributesDoc, attribute); // nested arguments get added as sub-docs
			}
		} 	// end for
		
		// add simple attributes to attributes doc
		
		IDataCursor attribsCursor = attributesDoc.getCursor();
		
		for (String key : attribs.keySet())
			IDataUtil.put(attribsCursor, key, attribs.get(key));

		attribsCursor.destroy();
					
		if (id == null || id.length() == 0)
			id = getUserIdUsingGUID(guidbytes, _userIdAttribute);
		
		// can't process users without a valid id
		
		if (id != null)
		{
			// setup principal doc
			
			IData doc = IDataFactory.create();
			IDataCursor dc = doc.getCursor();
			
			// check if really new
			
			if (!type.equals("DEL") && changeDate != null && changeDate.after(newDate))
				type ="CHG";
			
			IDataUtil.put(dc, "type", type);
			IDataUtil.put(dc, "id", id);
			IDataUtil.put(dc, "lastName", lastName);
			IDataUtil.put(dc, "firstName", firstName);
			IDataUtil.put(dc, "email", email);
			IDataUtil.put(dc, "isDeleted", isDeleted);
		
			IDataUtil.put(dc, "attributes", attributesDoc);
		
			if (returnCodes != null)
				IDataUtil.put(dc, "returnCodes", returnCodes);
		
			dc.destroy();
			
			return doc;
		}
		else
		{
			debugLog("Ignoring ldap update '" + guid + "' for user without " + _userIdAttribute);
			
			return null;
		}
	}
	
	private IData convertResponseCodeToDoc() throws NamingException
	{
		IData responseCodes = null;

		Control[] rspCtls = getContext().getResponseControls();
		
		if (rspCtls != null)
		{
			responseCodes = IDataFactory.create();
			IDataCursor c = responseCodes.getCursor();
			
			for (int i=0; i < rspCtls.length; i++)
			{
				Control r = rspCtls[i];

				IDataUtil.put(c, r.getID(), r.getEncodedValue());
			}
			
			c.destroy();
		}	
		
		return responseCodes;
	}
	
	private void addAttributeToDocument(IData doc, Attribute attribute) throws NamingException
	{
		IDataCursor c = doc.getCursor();
		
		if (attribute.size() > 1)
		{
			IData childDoc = IDataFactory.create();					
			IDataUtil.put(c, attribute.getID(), childDoc);
				
			IDataCursor sc = childDoc.getCursor();
			
			for (NamingEnumeration<?> an = attribute.getAll(); an.hasMore();)
			{
				Object obj = an.next();
					
				if (obj instanceof Attribute)
				{
					addAttributeToDocument(childDoc, (Attribute) obj);
				}
				else if (obj instanceof String)	
				{
					String a = (String) getAttributeValue(attribute);
					
					if (a != null)
						IDataUtil.put(sc, attribute.getID(), a);
				}
				else
				{
					Object a = getAttributeValue(attribute);

					if (a != null)
						IDataUtil.put(sc, attribute.getID(), a.toString());
				}
			}
			
			sc.destroy();
		}
		else
		{
			Object obj = getAttributeValue(attribute);
			
			if (obj != null)
			{
				if (obj instanceof String)
					IDataUtil.put(c, attribute.getID(), attribute.get());
				else
					IDataUtil.put(c, attribute.getID(), attribute.get().toString());
			}
		}
		
		c.destroy();
	}
	
	public void debugLog(String debugLevel, String message)
	{
		if (_altLogger == null)
		{
			IData input = IDataFactory.create();
			IDataCursor inputCursor = input.getCursor();
			IDataUtil.put(inputCursor, "message", message);
			IDataUtil.put(inputCursor, "function", "com.ocp.contactmgmt");
			IDataUtil.put(inputCursor, "level", debugLevel);

			inputCursor.destroy();

			try
			{
				setInvokeState(UserManager.getUser(_wmUserId));
			
				Service.doInvoke("pub.flow", "debugLog", input);
			}
			catch( Exception e)
			{
				logError(e);
				logErrorMessage("Cannot log message: " + message);
			}   
		}
		else
		{
			try {
				if (_altLogFile.exists())
					Files.write(Paths.get(_altLogger), message.getBytes(), StandardOpenOption.APPEND);
				else
					Files.write(Paths.get(_altLogger), message.getBytes(), StandardOpenOption.CREATE);
			} catch (IOException e) 
			{
				logError(e);
				logErrorMessage("Cannot log message: " + message);
			}
		}
	}
	 
	private void setInvokeState(User user)
	{
		Session session = Service.getSession();
		
		if (session == null)
			session = new Session("com.ocp.contactmgmt");
		
		InvokeState state = InvokeState.getCurrentState();
		
		state = new InvokeState();
		InvokeState.setCurrentState(state);
		
		state.setSession(session);
		InvokeState.setCurrentUser(user);			
	}
	
	private Date dateAtMidnight()
	{
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.clear(Calendar.HOUR);
		cal.clear(Calendar.MINUTE);
		cal.clear(Calendar.SECOND);
		cal.clear(Calendar.MILLISECOND);

		return cal.getTime();
	}
	
	public static String[] mergeFixedAndUserAttributes(String[] userReturnAttributes, String[] fixesReturnAttributes)
	{
		String[] _returnAttributes = new String[userReturnAttributes.length + fixesReturnAttributes.length];
			  
		for (int i=0; i<fixesReturnAttributes.length; i++)
			_returnAttributes[i] = fixesReturnAttributes[i];
			 
		for (int i=0; i<userReturnAttributes.length; i++)
			_returnAttributes[i+fixesReturnAttributes.length] = userReturnAttributes[i];
	
		return _returnAttributes;
	}
}
