package com.jc.ldap.activedirectory.listener;

import javax.naming.ldap.Control;

/**
 * Used to register for detection of object changes when setting up {@link javax.naming.directory.SearchControls}
 * instance with Active Directory. Based on Persistent Control protocol which does not indicate what
 * attributes have change when used with Active Directory. 
 * 
 * Not used in our implementation, here only for documentation purposes. Please refer instead to {@link DirSyncControl}
 * and {@link DeleteControl}
 * 
 * @author John Carter
 *
 */
public class NotifyControl implements Control 
{
	private static final long serialVersionUID = -1233470058767163049L;
	
	public byte[] getEncodedValue() 
     {
             return new byte[] {};
     }
      
     public String getID()
     {
          return "1.2.840.113556.1.4.528"; // Active Directory persistent search flag
     }
       
      public boolean isCritical() 
      {
          return true;
     }
}
	