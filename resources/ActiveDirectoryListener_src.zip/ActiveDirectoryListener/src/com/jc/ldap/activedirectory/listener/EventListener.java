package com.jc.ldap.activedirectory.listener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.NoSuchElementException;
import java.util.TimeZone;


import javax.naming.InvalidNameException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

/**
 * Abstract implementation for building a robust threaded ldap event listener for object changes.
 * 
 * @author John Carter
 *
 */
public abstract class EventListener extends Thread
{
	private LdapContext						_ctx;
	private Hashtable<String, String> 		_env;
	private String							_searchBase;
	private SearchControls					_searchCtls;
	
	private boolean							_pleaseStop;
	private boolean							_ignoreConnectionErrors;
	private String							_debugLevel;
	
	private Exception						_error;
	
	/**
	 * Establish a listener object
	 * 
	 * @param env  Hashtable of ldap attributes to setup connection
	 * @param searchBase  directory root to scan, must a valid domain partition
	 * @param searchFilter	filter for active directory search (e.g. (&(objectClass=person)(objectClass=user))
	 * @param returnAttributes Optional list of attributes to check for updates, otherwise all attributes will be checked
	 * @param SearchControls Defines criteria for search such subtree and attributes to return
	 */
	public EventListener(Hashtable<String, String> env, String searchBase, SearchControls searchCtls, String debugLevel) throws NamingException
	{
		super("com.ocp.contactmgmt.app.ldap.ad.register.run");
		
		_env = env;
		
		_searchBase = searchBase;
		_searchCtls = searchCtls;
				
		if (debugLevel != null)
			_debugLevel = debugLevel;
		else
			_debugLevel = "Debug";
		
		_pleaseStop = false;
	}
	
	public String getSearchBase()
	{
		return _searchBase;
	}
	
	public Hashtable<String, String> getEnv()
	{
		return _env;
	}
	
	public SearchControls getSearchControls()
	{
		return _searchCtls;
	}
	
	public LdapContext getContext()
	{
		return _ctx;
	}
		
	public void setContext(LdapContext ctx)
	{
		_ctx = ctx;
	}
	
	public Exception getConnectionError()
	{
		return _error;
	}
	
	public void setConnectionError(String e)
	{
		_error = new Exception(e);
	}
	
	public void setConnectionError(Exception e)
	{
		_error = e;
	}
	
	/**
	 * Implement for custom error tracing
	 * 
	 * @param e
	 * @param message
	 */
	public abstract void logError(Exception e, String message);
	
	/**
	 * Implement for custom error tracing
	 * @param e
	 */
	public abstract void logError(Exception e);
	
	/**
	 * Implement for custom error tracing
	 * 
	 * @param error
	 */
	public abstract void logErrorMessage(String error);
	
	/**
	 * Implement to ensure logging
	 * 
	 * @param type
	 * @param message
	 */
	public abstract void debugLog(String type, String message);
	
	/**
	 * Implement to process event changes received from ldap server
	 * 
	 * @param attrs - Attributes associated with ldap change event
	 */
	protected abstract void processNotification(Attributes attrs);

	/**
	 * This is the primary method to be called to start up the service, returns immediately
	 * with the startup and run look managed in separate threads. Use {@link pleaseStop()}
	 * to gracefully shutdown.
	 * 
	 * Any connection errors are logged via your implementation of {@link #logError()}
	 * 
	 * @param restartInterval - Optional parameter to force the reconnection after the given interval
	 */
	public void startup(final long restartInterval)
	{			
		new Thread(new Runnable() {
			
			@Override
			public void run() 
			{	
				// First establish connection

				debugLog("waiting for connection");
				
				Thread connectThread = connectWithRestart(restartInterval);
				
				synchronized(connectThread)
				{
					try {
						connectThread.wait();
					} catch (InterruptedException e) {}
				}
				//now start run loop
				
				if (!_pleaseStop)
				{
					debugLog("Starting ldap run loop");
					EventListener.this.start();
				}
				else
				{
					debugLog("*** listener stopped99 ***");
				}
			}
		}, "com.ocp.contactmgmt.app.ldap.ad.register.start").start();
	}
	
	/** 
	 * Call this method to gracefully shutdown the listener
	 * 
	 * @throws NamingException
	 */
	public void pleaseStop() throws NamingException
	{
		_pleaseStop = true;
		
		debugLog("stopping context");
		
		if (_ctx != null)
			_ctx.close();			
		else
			logErrorMessage("No ldap context to close");
	
		debugLog("stopped");
	}
	
	/**
	 * Return true if {@link #pleaseStop()} has been called on this listener
	 * 
	 * @return true if stopping, false {@link #pleaseStop()} not called
	 */
	public boolean isStopping()
	{
		return _pleaseStop;
	}
	
	protected Thread connectWithRestart(final long interval)
	{		
		Thread t = new Thread(new Runnable() {
			
			@Override
			public synchronized void run() {
		
				while (!_pleaseStop)
				{
					_ignoreConnectionErrors = true; // ensure run loop will not report any errors whilst restarting
			
					if (_ctx != null)
					{
						try {
							pleaseStop();
						} catch (NamingException e) {}
					}
			
					connect();
			
					// connection established, wake waiting thread so run loop can be started
					
					_ignoreConnectionErrors = false;
					
					debugLog("Notifying ldap run loop");
					
					this.notifyAll();
					
					try {
						Thread.sleep(interval);
					} catch (InterruptedException e) {} // restart interval
			
					if (!_pleaseStop && interval > 0)
						debugLog("restarting ldap connection.....");
					else
						break; // thread completes, no automatic restart requested
				}
			}
		}, "com.ocp.contactmgmt.app.ldap.ad.register.reliable.connect");
		
		t.start();
		
		return t;
	}
	
	protected void connect()
	{
		while (!_pleaseStop && !pleaseStart())
		{
			_ignoreConnectionErrors = false; // run loop will report any connection errors
			
			debugLog("ldap connection failed, will attempt to reconnect in 30 seconds.....");
				
			try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				logError(e);
			} // wait 30 seconds to try and re-establish connection
		}
	}
	
	/** 
	 * Don't call this directly, use {@link startup()} instead
	 * @return
	 */
	protected boolean pleaseStart()
	{		
		return true;
	}
	
	/**
	 * Used by run loop to process incoming change events from ldap service
	 * 
	 * @param search - Enumerator or received change events
	 * @return int - Number of events found and processed
	 * 
	 * @throws NoResultsException
	 * @throws NamingException
	 */
	protected int processSearch(NamingEnumeration<SearchResult> search) throws NoResultsException, NamingException
	{
		int runCount = 0;
		
		while (!_pleaseStop && search.hasMore())
		{				
			SearchResult sr = null;
				
			sr = (SearchResult) search.next();
           		
			if (sr != null)
				debugLog("Got notification (" + runCount++ + ") :" + sr.getAttributes().size());
			else
				debugLog("Got null attribute notification:");

			if (!_pleaseStop && sr != null && sr.getAttributes() != null)
				processNotification(sr.getAttributes());
			else if (sr == null && !_ignoreConnectionErrors)
				throw new NoResultsException("ldap notifier returned null SearchResult");
			else
				debugLog("Got empty attributes: " + sr.getAttributes().size());
		} // end while
		
		return runCount;
	}
	
	protected Object getAttributeValue(Attribute attribute) throws NamingException
	{
		try 
		{
			return attribute.get();
		}
		catch (NoSuchElementException e)
		{
			return null;
		}
	}
	
	protected String convertBytesToString(byte[] bytes)
	{
		StringBuffer out = new StringBuffer();
					
		for (int i = 0; i < bytes.length; i++)
		{
			String add = Integer.toHexString(bytes[i] & 0xff);
			if (add.length() == 1)
				out.append(0);
			
			out.append(add);
		}
			
		return out.toString();
	}
	
	protected Date parseAdDate(String adDate)
	{
		if (adDate == null)
			return null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		sdf.setTimeZone(TimeZone.getDefault());
		
		try {
			return sdf.parse(adDate);
		}
		catch (ParseException e)
		{
			logErrorMessage("Unable to parse active directory date '" + adDate + "' :" + e);
		}
		
		return null;
	}
	
	public void debugLog(String message)
	{
		debugLog(_debugLevel, message);
	}

	protected String getUserIdUsingGUID(byte[] guid, String userTypeId)
	{
		String id = null;
		Attributes attribs = null;
		
		try
		{
			attribs = getAttributesForGUID(guid);
			
			if (attribs != null)
			{
				debugLog("Info", "Got attributes " + attribs.size() + " for objectGUID: " + guid);
				
				Attribute a = attribs.get(userTypeId);
		
				if (a != null)
					id = (String) a.get();
				else
					debugLog("Info", "No '" + userTypeId + "' defined user with objectGUID: " + guid);
			}
			else
			{
				debugLog("Info", "No user with objectGUID: " + guid);
			}
		}
		catch(InvalidNameException e)
		{
			debugLog("Info", "No '" + userTypeId + "' defined user with objectGUID: " + guid);
		}
		catch(NamingException e)
		{
			debugLog("Info", "No user with objectGUID: " + guid);
		}
		
		return id;
	}
	
	protected Attributes getAttributesForGUIDString(String guid) throws NamingException
	{			
		return getAttributesForGUID(convertGUIDStringToBytes(guid));
	}
	
	private Attributes getAttributesForGUID(byte[] guid) throws NamingException
	{	
		LdapContext ctx = new InitialLdapContext(_env, null);
		
		NamingEnumeration<SearchResult> search = null;
		Attributes attributes = null;

		try 
		{
			String bytesGUID = convertByteGUIDToByteString(guid);
			String guidFilter = "(objectGUID=" + bytesGUID + ")";
			search = ctx.search(_searchBase, guidFilter, _searchCtls);
		
			if (search.hasMore())
			{					
				SearchResult r = search.next();
				attributes = r.getAttributes();
			}
		}
		finally
		{
			if (search != null)
				search.close();

			ctx.close();
		}
		
		return attributes;
	}
	
	private String convertByteGUIDToByteString(byte[] GUID)
	{
		String byteGUID = "";
		
		//Convert the GUID into string using the byte format
		
		for (int c=0;c<GUID.length;c++) 
		{
			byteGUID = byteGUID + "\\" + addLeadingZero((int)GUID[c] & 0xFF);
		}
		
		return byteGUID;
	}
	
	private byte[] convertGUIDStringToBytes(String guid)
	{						
		byte[] part3 = hexStringToByteArray(guid.substring(0, 2));	
		byte[] part2 = hexStringToByteArray(guid.substring(2, 4));			
		byte[] part1 = hexStringToByteArray(guid.substring(4, 6));			
		byte[] part0 = hexStringToByteArray(guid.substring(6, 8));
		
		byte[] part5 = hexStringToByteArray(guid.substring(9, 11));
		byte[] part4 = hexStringToByteArray(guid.substring(11, 13));

		byte[] part7 = hexStringToByteArray(guid.substring(14, 16));
		byte[] part6 = hexStringToByteArray(guid.substring(16, 18));
		
		byte[] part8 = hexStringToByteArray(guid.substring(19, 21));
		byte[] part9 = hexStringToByteArray(guid.substring(21, 23));
		
		byte[] part10 = hexStringToByteArray(guid.substring(24, 26));
		byte[] part11 = hexStringToByteArray(guid.substring(26, 28));
		byte[] part12 = hexStringToByteArray(guid.substring(28, 30));
		byte[] part13 = hexStringToByteArray(guid.substring(30, 32));
		byte[] part14 = hexStringToByteArray(guid.substring(32, 34));	
		byte[] part15 = hexStringToByteArray(guid.substring(34));
			
		byte[] all = new byte[part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length + part8.length + part9.length + part10.length + part11.length + part12.length + part13.length + part14.length + part15.length];

		System.arraycopy(part0, 0, all, 0, part0.length);
		System.arraycopy(part1, 0, all, part0.length, part1.length);
		System.arraycopy(part2, 0, all, part0.length + part1.length, part2.length);
		System.arraycopy(part3, 0, all, part0.length + part1.length + part2.length, part3.length);
		System.arraycopy(part4, 0, all, part0.length + part1.length + part2.length + part3.length, part4.length);
		System.arraycopy(part5, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length, part5.length);
		System.arraycopy(part6, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length, part6.length);
		System.arraycopy(part7, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length, part7.length);
		System.arraycopy(part8, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length, part8.length);
		System.arraycopy(part9, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length + part8.length, part9.length);
		System.arraycopy(part10, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length + part8.length + part9.length, part10.length);
		System.arraycopy(part11, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length + part8.length + part9.length + part10.length, part11.length);
		System.arraycopy(part12, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length + part8.length + part9.length + part10.length + part11.length, part12.length);
		System.arraycopy(part13, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length + part8.length + part9.length + part10.length + part11.length + part12.length, part13.length);
		System.arraycopy(part14, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length + part8.length + part9.length + part10.length + part11.length + part12.length + part13.length, part14.length);
		System.arraycopy(part15, 0, all, part0.length + part1.length + part2.length + part3.length + part4.length + part5.length + part6.length + part7.length + part8.length + part9.length + part10.length + part11.length + part12.length + part13.length + part14.length, part15.length);

		return all;
	}
	
	private byte[] hexStringToByteArray(String hexString)
	{			
		int len = hexString.length();
		byte[] out = new byte[len/2];
		
		for (int i = 0; i < len; i +=2)
			out[i/2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4) + Character.digit(hexString.charAt(i+1), 16));
		
		return out;
	}
	
	protected String convertByteGuidToString(byte[] GUID)
	{
		String strGUID = "";
	
	//convert the GUID into string format
		
		strGUID = strGUID + addLeadingZero((int)GUID[3] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[2] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[1] & 0xFF); 
		strGUID = strGUID + addLeadingZero((int)GUID[0] & 0xFF);
		strGUID = strGUID + "-";
		strGUID = strGUID + addLeadingZero((int)GUID[5] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[4] & 0xFF);
		strGUID = strGUID + "-";
		strGUID = strGUID + addLeadingZero((int)GUID[7] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[6] & 0xFF);
		strGUID = strGUID + "-";
		strGUID = strGUID + addLeadingZero((int)GUID[8] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[9] & 0xFF);
		strGUID = strGUID + "-";
		strGUID = strGUID + addLeadingZero((int)GUID[10] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[11] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[12] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[13] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[14] & 0xFF);
		strGUID = strGUID + addLeadingZero((int)GUID[15] & 0xFF);
		
		return strGUID;
	}
	
	private String addLeadingZero(int k) 
	{
		return (k<0xF) ? "0" + Integer.toHexString(k) : Integer.toHexString(k);
	}
	
	public class NoResultsException extends Exception
	{
		private static final long serialVersionUID = 5609409543651176088L;

		public NoResultsException(String message)
		{
			super(message);
		}
	}
}