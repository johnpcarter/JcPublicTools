package com.jc.ldap.activedirectory.listener;

import java.io.IOException;
import java.util.Hashtable;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.Control;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import com.wm.app.b2b.server.ServiceException;

/**
 * Abstract implementation to event {@link EventListener} in order to implement Active Directory DirSyncControl
 * listener.
 * 
 * @author John Carter
 *
 */
public abstract class DirSyncEventListener extends EventListener
{
	private static final long		POLL_INTERVAL = 30000;
	
	private DirSyncControl 			_dirSyncControl;
	private byte[] 					_cookie;
	private String					_searchFilter;
	
	/**
	 * 
	 * @param env  Hashtable of ldap attributes to setup connection
	 * @param searchBase  directory root to scan, must a valid domain partition
	 * @param searchFilter	filter for active directory search (e.g. (&(objectClass=person)(objectClass=user))
	 * @param returnAttributes Optional list of attributes to check for updates, otherwise all attributes will be checked
	 * @param SearchControls Defines criteria for search such subtree and attributes to return
	 * @throws NamingException
	 * @throws ServiceException
	 */
	public DirSyncEventListener(Hashtable<String, String> env, String searchBase, String searchFilter, SearchControls searchCtls, String debugLevel) throws NamingException
	{
		super(env, searchBase, searchCtls, debugLevel);
		_searchFilter = searchFilter;
	}

	protected abstract void persistCookie(byte[] cookie);                   

	protected abstract byte[] restoreCookie();
	
	public Control[] getRequestControls() throws IOException
	{
		_cookie = restoreCookie();
			
		if (_cookie == null)
			_dirSyncControl = new DirSyncControl(_cookie);
		else
			_dirSyncControl = new DirSyncControl();
			
		return new Control[] {_dirSyncControl};
	}
	
	@Override
	protected boolean pleaseStart()
	{		      
		boolean success = true;
 
		super.pleaseStart();
		
		try 
		{
		 //bind to the domain controller

			LdapContext ctx = new InitialLdapContext(getEnv(), null);
	
			ctx.setRequestControls(getRequestControls());
      			
			setContext(ctx);
			
			debugLog("started ldap listener");	
			
			// dirsync requires that we first process all changes since last request, then reset via cookie
			
			try 
			{					
				if (_cookie == null || _cookie.length == 0)
					_cookie = establishCookieBasedSearch();		
				else
					debugLog("Searching using pre-existing cookie: " + convertBytesToString(_dirSyncControl.getCookie()));
			}
			catch (NamingException e )
			{
				setConnectionError(e);		
			}
			
			success = true;
		} 
		catch (NamingException e) 
		{
			setConnectionError("Failed to connect to ldap server: " + e);
		}
		catch (IOException e) 
		{
			setConnectionError("Failed to establish context with saved cookie: " + e);
		}
		
		return success;
	}
	
	public void run() 
	{		      
		int errorCount = 0;
		int runCount = 0;
		
		LdapContext ctx = getContext();
		
		debugLog("Establish search using cookie:" + convertBytesToString(_cookie));
			
		if (_cookie == null)
		{
			logErrorMessage("Error reading ldap cookie for changes, will stop");
			
			this.debugLog("*** listener stopped88 ***");

			return;
		}
		
		NamingEnumeration<SearchResult> search = null;
			
		while (!isStopping())
		{
			//debugLog("setting cookie for change monitor : " + convertBytesToString(_cookie));
			
			try 
			{
				ctx.setRequestControls(new Control[] {new DirSyncControl(_cookie)});  
			
				search = ctx.search(getSearchBase(), _searchFilter, getSearchControls());
														
				runCount += processSearch(search);
			
				_cookie = getDirSyncResponseControl(getContext()).getResponseCookie();
			}
			catch(NamingException e)
			{
				errorCount += 1;
				
				logError(e, "Error polling ldap server for changes: " + e.getMessage());
			} 
			catch(IOException e)
			{
				errorCount += 1;
				logError(e, "Error setting ldap cookie for change monitor");
			} 
			catch (NoResultsException e) 
			{
				logError(e);
			}
			finally
			{
				try {
					if (search != null)
						search.close();
					else
						logErrorMessage("No ldap search binding to close");
				}
				catch(Exception e)
				{
					logError(e, "Error closing ldap search binding: " + e.getMessage());
				}
				
				if (errorCount > 3)
				{
						// try to re-establish connection
					
					errorCount = 0;
					connect();
				}
			
				//debugLog("Waiting for notification (" + runCount + ").....");
				
				try {
					Thread.sleep(POLL_INTERVAL);
				} catch (InterruptedException e) {
					// do now't
				}
			} // end run loop
		}
		
		debugLog("Saving cookie: " + convertBytesToString(_cookie));
		persistCookie(_cookie);
		
		this.debugLog("*** listener stopped ***");
	}
	
	private byte[] establishCookieBasedSearch() throws NamingException, IOException
	{
		// perform basic search in order to establish our cookie
			
		int ttotal = 0;
		int btotal = 0;
		DirSyncResponseControl response = null;
		byte[] cookie = null;
		byte[] cookieNotSet = null;
		
		LdapContext ctx = getContext();

		while (!isStopping() && (response == null || response.hasMore()))
		{
			btotal = 0;
			
			if (cookieNotSet == null || cookie != cookieNotSet)
			{
				debugLog("fetching next ldap batch to monitor for cookie");

				ctx.setRequestControls(new Control[] {new DirSyncControl(cookie)});
				cookieNotSet = cookie;
			}
			
			NamingEnumeration<SearchResult> search = ctx.search(getSearchBase(), _searchFilter, getSearchControls());

			while (search.hasMoreElements())
			{
				SearchResult sr = (SearchResult) search.next(); 
				btotal += 1;
			}
			
			debugLog("fetching original ldap records to monitor: " + btotal+ " of " + ttotal);

			response = getDirSyncResponseControl(ctx);

			cookie = response.getResponseCookie();
		
			ttotal += btotal;
			
			search.close();
		} // end while
		
		debugLog("initial ldap records to monitor: " + ttotal);
		
		if (cookie != null)
		{
			debugLog("Saving cookie: " + convertBytesToString(cookie));
			persistCookie(cookie);
		}
	
		setContext(ctx);
		
		return cookie;
	}
	
	public DirSyncResponseControl getDirSyncResponseControl(LdapContext ctx) throws NamingException
	{
		Control[] rspCtls = ctx.getResponseControls();
		DirSyncResponseControl control = null;
		
		if (rspCtls != null)
		{
			for (int i=0; i < rspCtls.length; i++)
			{
				Control rsp = rspCtls[i];

				try {
					control = new DirSyncResponseControl(rsp.getID(), true, rsp.getEncodedValue());
					
					break;
				}
				catch (IOException e)
				{
					debugLog("No cookie found in ldap response: " + rsp.getID());
				}
			}
		}
		
		return control;
	}
}