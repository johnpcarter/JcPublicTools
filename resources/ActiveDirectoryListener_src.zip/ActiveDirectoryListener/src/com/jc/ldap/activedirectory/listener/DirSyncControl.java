package com.jc.ldap.activedirectory.listener;

import java.io.IOException;

import javax.naming.ldap.BasicControl;

import com.sun.jndi.ldap.Ber;
import com.sun.jndi.ldap.BerEncoder;

/**
 * Used to register for detection of object changes when setting up {@link javax.naming.directory.SearchControls}
 * instance with Active Directory.
 * 
 * @author John Carter
 *
 */
public class DirSyncControl extends BasicControl
{
	private static final long serialVersionUID = 5335472570863208424L;
	public static final java.lang.String OID = "1.2.840.113556.1.4.841";
	public static final int LDAP_DIRSYNC_OBJECT_SECURITY = 0x00000001;
	public static final int LDAP_DIRSYNC_ANCESTORS_FIRST_ORDER = 0x00000800;
	public static final int LDAP_DIRSYNC_PUBLIC_DATA_ONLY = 0x00002000;
	public static final int LDAP_DIRSYNC_INCREMENTAL_VALUES = 0x80000000;
	private static final byte[] EMPTY_COOKIE = new byte[0];
	
	private int flags;
	private int maxReturnLength;
	private byte[] _cookie;
	
	public DirSyncControl() 
	{
		super(OID, true, null);
		flags = LDAP_DIRSYNC_OBJECT_SECURITY | LDAP_DIRSYNC_INCREMENTAL_VALUES;
		//flags = LDAP_DIRSYNC_OBJECT_SECURITY | LDAP_DIRSYNC_INCREMENTAL_VALUES | LDAP_DIRSYNC_PUBLIC_DATA_ONLY;
		
		maxReturnLength = Integer.MAX_VALUE;

		if (_cookie == null)
			getCookie();
		
		if (_cookie == null) 
			_cookie = EMPTY_COOKIE;
			
		try {
		super.value = setEncodedValue(maxReturnLength, _cookie);
		} catch(IOException e)
		{
			// Can't happen
		}
	}
	
	public DirSyncControl(byte[] cookie) throws IOException 
	{
		super(OID, true, cookie);
		flags = LDAP_DIRSYNC_OBJECT_SECURITY | LDAP_DIRSYNC_INCREMENTAL_VALUES;
		//flags = LDAP_DIRSYNC_OBJECT_SECURITY | LDAP_DIRSYNC_INCREMENTAL_VALUES | LDAP_DIRSYNC_PUBLIC_DATA_ONLY;

		maxReturnLength = Integer.MAX_VALUE;
	
		if (cookie == null)
			_cookie = EMPTY_COOKIE;
		else
			_cookie = cookie;
		
		super.value = setEncodedValue(maxReturnLength, _cookie);
	}
	
	public byte[] getCookie()
	{	
		return _cookie;
	}
	
	private byte[] setEncodedValue(int maxAttrCount, byte[] cookie) throws IOException
	{
		BerEncoder be = new BerEncoder();
		be.beginSeq(Ber.ASN_SEQUENCE | Ber.ASN_CONSTRUCTOR);
		be.encodeInt(flags);
		be.encodeInt(maxReturnLength);
		be.encodeOctetString(cookie, Ber.ASN_OCTET_STR);
		be.endSeq();
	
		return be.getTrimmedBuf();
	}
}