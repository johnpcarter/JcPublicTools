package com.jc.ldap.activedirectory.listener;

import java.io.IOException;

import com.sun.jndi.ldap.Ber;
import com.sun.jndi.ldap.BerDecoder;

import javax.naming.ldap.BasicControl;

/**
 * Used to interpret response from an Active Directory search request using {@link DirSyncControl}
 * 
 * @author John Carter
 *
 */
public class DirSyncResponseControl extends BasicControl 
{    
	private static final long serialVersionUID = -7287142751748806621L;

    private int _flag;
    private byte[] _cookie;
    
    public DirSyncResponseControl(String id, boolean criticality, byte[] value) throws IOException 
    {
        super(id, criticality, value);
       
        _cookie = new byte[0];

        if (value != null && value.length > 0) 
        {
            BerDecoder decoder = new BerDecoder(value, 0, value.length);
            decoder.parseSeq(null);
            _flag = decoder.parseInt();
            int maxLength = decoder.parseInt();
            
            _cookie = decoder.parseOctetString(Ber.ASN_OCTET_STR, null);
        }
    }

    public byte[] getResponseCookie() 
    {
    	if (_cookie.length != 0) 
    	{
    		return _cookie;
    	} 
    	else 
    	{
            return null;
    	}
    }
    
    public void setResponseCookie(byte[] cookie)
    {
    	_cookie = cookie;
    }
    
    public boolean hasMore() 
    {
    	return (0 != _flag);
    }
}
