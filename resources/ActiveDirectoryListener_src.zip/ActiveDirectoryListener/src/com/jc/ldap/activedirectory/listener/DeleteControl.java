package com.jc.ldap.activedirectory.listener;

import javax.naming.ldap.Control;

/**
 * Used to register for detection of object deletion when setting up {@link javax.naming.directory.SearchControls}
 * instance with Active Directory.
 * 
 * @author John Carter
 *
 */
public class DeleteControl implements Control
{
	private static final long serialVersionUID = -6514503072602555620L;

	public byte[] getEncodedValue() 
	{
		return new byte[] {};
    }
      
    public String getID()
    {
    	return "1.2.840.113556.1.4.417"; // Active Directory persistent search flag
    }
       
    public boolean isCritical() 
    {
    	return true;
    }
}